#!/usr/bin/env bash
# Shared ANSI UI helpers for HyprFlux installer / session scripts (English).

if [[ "${HYPRFLUX_UI_LOADED:-0}" == "1" ]]; then
  return 0 2>/dev/null || true
fi
HYPRFLUX_UI_LOADED=1

HF_BOLD=$'\033[1m'
HF_DIM=$'\033[2m'
HF_RESET=$'\033[0m'
HF_CYAN=$'\033[38;2;88;196;221m'
HF_BLUE=$'\033[38;2;69;133;186m'
HF_GREEN=$'\033[38;2;142;192;124m'
HF_AMBER=$'\033[38;2;232;176;84m'
HF_ROSE=$'\033[38;2;232;116;132m'
HF_TEXT=$'\033[38;2;220;224;232m'
HF_MUTED=$'\033[38;2;140;150;168m'

# curl|bash leaves stdin as the script pipe; interactive I/O must use a real TTY.
# -r/-w on /dev/tty can succeed even when open fails (ENXIO) with no controlling TTY —
# always probe with a real open, not test(1) mode bits.
HF_TTY=""
if [[ -n "${HF_TTY_OVERRIDE:-}" ]]; then
  HF_TTY="$HF_TTY_OVERRIDE"
elif { true </dev/tty; } 2>/dev/null && { true >/dev/tty; } 2>/dev/null; then
  HF_TTY="/dev/tty"
fi

# Path suitable for `cmd <"$HF_SUDO_IN"`; /dev/null when detached + sudo already cached.
hf_sudo_in() {
  if [[ -n "${HF_TTY:-}" ]] && { true <"$HF_TTY"; } 2>/dev/null; then
    printf '%s' "$HF_TTY"
  elif [[ -t 0 ]]; then
    printf '%s' "/dev/stdin"
  else
    printf '%s' "/dev/null"
  fi
}

# Refresh sudo timestamp when possible; succeed if already cached (nohup/tmux-safe).
hf_ensure_sudo() {
  if [[ "$(id -u)" -eq 0 ]]; then
    return 0
  fi
  if sudo -n true 2>/dev/null; then
    return 0
  fi
  local sin
  sin="$(hf_sudo_in)"
  if [[ "$sin" == "/dev/null" ]]; then
    hf_err "sudo needs a password but no controlling TTY is available"
    hf_err "Authenticate first (sudo -v), or run under SSH -tt / a real terminal."
    return 1
  fi
  sudo -v <"$sin"
}

hf_supports_color() {
  [[ -t 1 ]] && [[ "${NO_COLOR:-}" == "" ]] && [[ "${TERM:-}" != "dumb" ]]
}

if ! hf_supports_color; then
  HF_BOLD=""; HF_DIM=""; HF_RESET=""
  HF_CYAN=""; HF_BLUE=""; HF_GREEN=""; HF_AMBER=""; HF_ROSE=""; HF_TEXT=""; HF_MUTED=""
fi

hf_banner() {
  cat <<EOF
${HF_CYAN}${HF_BOLD}
  ┌──────────────────────────────────────────────┐
  │                                              │
  │   H y p r F l u x                            │
  │   ${HF_TEXT}Arch + Hyprland full desktop bootstrap${HF_CYAN}     │
  │                                              │
  └──────────────────────────────────────────────┘
${HF_RESET}
EOF
}

hf_section() {
  printf '\n%s▸ %s%s\n' "$HF_BLUE$HF_BOLD" "$1" "$HF_RESET"
}

hf_info() {
  printf '  %s•%s %s%s%s\n' "$HF_CYAN" "$HF_RESET" "$HF_TEXT" "$1" "$HF_RESET"
}

hf_ok() {
  printf '  %s✓%s %s\n' "$HF_GREEN" "$HF_RESET" "$1"
}

hf_warn() {
  printf '  %s!%s %s\n' "$HF_AMBER" "$HF_RESET" "$1"
}

hf_err() {
  printf '  %s✗%s %s\n' "$HF_ROSE" "$HF_RESET" "$1" >&2
}

hf_step() {
  local current="$1" total="$2" label="$3"
  printf '  %s[%s/%s]%s %s\n' "$HF_DIM" "$current" "$total" "$HF_RESET" "$label"
}

hf_kv() {
  printf '  %s%-12s%s %s\n' "$HF_MUTED" "$1" "$HF_RESET$HF_TEXT" "$2$HF_RESET"
}

hf_box_line() {
  printf '  %s%s%s\n' "$HF_MUTED" "$1" "$HF_RESET"
}

# Read a line from the real terminal so curl|bash does not EOF-abort prompts.
hf_read_tty() {
  local prompt="$1"
  local __outvar="$2"
  local __line=""
  if [[ -n "$HF_TTY" ]]; then
    printf '%s' "$prompt" >"$HF_TTY"
    if ! IFS= read -r __line <"$HF_TTY"; then
      __line=""
    fi
  elif [[ -t 0 ]]; then
    printf '%s' "$prompt"
    IFS= read -r __line || __line=""
  else
    hf_err "No interactive TTY available. Use: bash <(curl -fsSL https://arch.vimalinx.com/install)"
    hf_err "Or set HF_YES=1 to skip confirmation."
    return 1
  fi
  printf -v "$__outvar" '%s' "$__line"
}
